## [1.0.0] 2020-09-14
### Original Release
- Started project with NextJS
- Added design from Argon Dashboard PRO React by Creative Tim
### Warning
_Warnings might appear while doing an npm install - they do not affect the UI or the functionality of the product, and they appear because of NodeJS and not from the product itself._
_While in development some of the plugins that were used for this product will throw some warnings - note, this only happens in development, the UI or the functionality of the product is not affected, also, if the issues will persist in React 17, we'll drop usage of those plugins, and replace them with other ones._
